exports.connection = {
	endpoint: "https://akelius-dictionary.documents.azure.com:443",
	authKey: "RMDPAVDJkuSxS1obv1L4hRXGRDrDwTXFQ5UbqFaot510hqhYOxQRaTS8qPAOZOXFagPFqAYUJ9lekVscl02kWQ=="
};

exports.names = {
	database: "dictionary",
	collection: "AkeliusTranslations"
}

module.exports = {
	"endpoint": "https://akelius-dictionary-test.documents.azure.com:443",
	"authKey": "Qcd1aqgVkrJUuWRXD3fcVlxUWhh5kRO5FCvQvXS02T3moe3Ci47PHE1bwHjIUFlG2Tr7YZPJmZ2YttGby0Wdzw==",
	"database": "dictionary-test",
	"collection": "akelius-translations-test"
}